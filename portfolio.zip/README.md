# Portfolio - Madivalayya Swamy

🚀 Personal portfolio website built with **HTML, TailwindCSS, and JavaScript**.

## Features
- Responsive design
- Animated hero section
- Projects showcase
- Contact form with interactive effects
- Clean modern UI

## How to Run
1. Clone the repo
2. Open `index.html` in any browser

## Deployment
Can be deployed on **GitHub Pages**, **Vercel**, or **Netlify**.
