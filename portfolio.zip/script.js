(function() {
const texts = ["Full Stack Developer", "React Specialist", "Node.js Expert", "UI/UX Enthusiast"];
let currentIndex = 0;
const textElement = document.getElementById('changing-text');
textElement.style.opacity = "0";
textElement.style.transform = "translateY(20px)";
textElement.style.display = "block";
textElement.style.transition = "opacity 0.5s ease, transform 0.5s ease";
textElement.style.color = "#4f46e5";
function changeText() {
textElement.style.opacity = "0";
textElement.style.transform = "translateY(20px)";
setTimeout(() => {
currentIndex = (currentIndex + 1) % texts.length;
textElement.textContent = texts[currentIndex];
textElement.style.opacity = "1";
textElement.style.transform = "translateY(0)";
}, 500);
}
// Initial display
setTimeout(() => {
textElement.textContent = texts[0];
textElement.style.opacity = "1";
textElement.style.transform = "translateY(0)";
}, 500);
setInterval(changeText, 3000);
// Add scroll animation
document.addEventListener('DOMContentLoaded', function() {
const animateOnScroll = function() {
const elements = document.querySelectorAll('.card-hover, .skill-bar, .timeline-connector');
elements.forEach(element => {
const elementPosition = element.getBoundingClientRect().top;
const screenPosition = window.innerHeight / 1.2;
if (elementPosition < screenPosition) {
element.classList.add('animate-fade-in');
}
});
};
window.addEventListener('scroll', animateOnScroll);
animateOnScroll(); // Run once on load
});
})();